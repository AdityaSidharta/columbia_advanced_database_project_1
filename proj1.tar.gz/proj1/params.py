ALPHA = 1.0
BETA = 0.9
GAMMA = 0.05
STEMMER = "lemmatize"
TOKENIZER = "word"
LANGUAGE = "english"
TOP_K = 2
